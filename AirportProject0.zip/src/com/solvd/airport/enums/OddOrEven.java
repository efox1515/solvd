package com.solvd.airport.enums;

public enum OddOrEven {
	
	ODD,
    EVEN;
    
    public static boolean isOdd(int number) {
        return number % 2 == 1;
    }
    
    public static boolean isEven(int number) {
        return number % 2 == 0;
    }
    
    public static OddOrEven getOddOrEven(int number) {
        if (isOdd(number)) {
            return OddOrEven.ODD;
        } else {
            return OddOrEven.EVEN;
        }
    }
}


