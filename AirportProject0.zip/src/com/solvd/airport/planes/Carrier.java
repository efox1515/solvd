package com.solvd.airport.planes;

public class Carrier extends Plane{
	
	public int weight;

	public int getWeight() {
		return weight;
	}

	public void setWeight(int weight) {
		this.weight = weight;
	}
	
	

}
