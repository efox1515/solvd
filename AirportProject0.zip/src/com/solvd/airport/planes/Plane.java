package com.solvd.airport.planes;

public abstract class Plane implements Ifly, IUnloadLandingGear, IDeployFlaps, IDisplayAntiCollisionLights, IEngageAutoPilot  {


	public String Abstract1 (String toString)
	{
		return"";
	}
	
	
	
	private String model;
	private int capacity;
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getCapacity() {
		return capacity;
	}
	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	
	

}
