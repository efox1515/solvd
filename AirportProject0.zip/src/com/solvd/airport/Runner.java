package com.solvd.airport;
import com.solvd.airport.exceptions.*;
import java.lang.Exception;
import com.solvd.airport.employees.Pilot;
import com.solvd.airport.employees.PlaneStaff;
import com.solvd.airport.passenger.Drink;
import com.solvd.airport.passenger.Meal;
import com.solvd.airport.planes.Carrier;
import com.solvd.airport.planes.Jet;
import com.solvd.airport.planes.Plane;
import com.solvd.airport.planes.RunwayLane;
import com.solvd.airport.planes.cruisingAlt;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.function.*;
import java.util.*;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

public class Runner {


	public final static void main(String args[]){

	

	
		Drink drink = new Drink(); 
		drink.setDrink("Coke");
		
		Meal meal = new Meal(); 
		meal.setMeal("Steak");
		
		Pilot name1 = new Pilot();
		name1.setName("Bob");
		
		PlaneStaff planeStaffNumber = new PlaneStaff();
		planeStaffNumber.setPlaneStaffNumber(20);
		
		RunwayLane runwayLane = new RunwayLane();
		runwayLane.setRunwaylane(4);
		
		
		Terminal gate = new Terminal();
		gate.setGate(8);

		Ticket flightnumber = new Ticket();
		flightnumber.setFlightnumber(10);
		
		Ticket luggageNumber = new Ticket();
		luggageNumber.setLuggagenumber(2);
		
		Ticket seat = new Ticket();
		seat.setSeat("A1");
		
		Plane carrier = new Carrier();
		carrier.setModel("747");
		
		}
	
}
