package com.solvd.airport.Lambdas;

public interface LambdaGenericInterfaceWithValue<T> {
	T GetValue();


}
