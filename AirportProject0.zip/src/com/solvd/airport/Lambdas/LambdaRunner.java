package com.solvd.airport.Lambdas;

import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.UnaryOperator;


public class LambdaRunner {
	public static void main (String[] args) {
	
	Consumer<String> consumer = (str) -> System.out.println("Received: " + str);
	consumer.accept("Hello World!");
	
	Function<String, Integer> function = (str) -> str.length();
	Integer length = function.apply("Hello World!");
	
	Predicate<String> predicate = (str) -> str.length() > 5;
	boolean result = predicate.test("Hello World!");
	
	Supplier<String> supplier = () -> UUID.randomUUID().toString();
	String uuid = supplier.get();

	UnaryOperator<Integer> square = x -> x * x;
    System.out.println(square.apply(5)); 

	}
}
