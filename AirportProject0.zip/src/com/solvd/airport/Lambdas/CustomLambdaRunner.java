package com.solvd.airport.Lambdas;

public class CustomLambdaRunner {
	public static void main (String[] args) {
		
		
		LambdaGenericInterfaceWithValue<Integer> integerLambdaGenericInterfaceWithValue = ()->12;
		System.out.println("[Custom Lambda Function One] "+integerLambdaGenericInterfaceWithValue.GetValue());

		LambdaGenericInterfaceStringDoubled<String> doubleString = (String s)->s.concat(s);
		System.out.println("[Custom Lambda Function Two] "+doubleString.GetDoubledString("OriginalString"));

		LambdaGenericInterfaceStringMultiplied<String> multipliedString = (s,i) -> s.repeat(i);
		System.out.println("[Custom Lambda Function Three] "+multipliedString.GetMultipliedString("AB", 3));

		
		
	}

}
