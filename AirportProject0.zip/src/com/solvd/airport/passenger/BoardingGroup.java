package com.solvd.airport.passenger;
import com.solvd.airport.Terminal;

public class BoardingGroup extends Terminal{
	
	private String boardingGroup;

	public String getBoardingGroup() {
		return boardingGroup;
	}

	public void setBoardingGroup(String boardingGroup) {
		this.boardingGroup = boardingGroup;
	}
	

}
