package com.solvd.airport.passenger;

import com.solvd.airport.Ticket;

public class FirstClass extends Ticket{
	
	public void skipLine() {}

}
