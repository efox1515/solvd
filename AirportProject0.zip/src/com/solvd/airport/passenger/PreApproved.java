package com.solvd.airport.passenger;

import com.solvd.airport.Ticket;

public class PreApproved extends Ticket {

	public void keepShoesOn () {}
}
