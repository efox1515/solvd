package com.solvd.airport.passenger;

public class Meal {

	private String meal;

	public String getMeal() {
		return meal;
	}

	public void setMeal(String meal) {
		this.meal = meal;
	}
}
