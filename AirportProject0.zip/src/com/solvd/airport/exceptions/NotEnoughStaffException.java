package com.solvd.airport.exceptions;

public class NotEnoughStaffException extends Exception {
	public NotEnoughStaffException(String ex) {
		super(ex);
	}
}
