package com.solvd.airport;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Ticket {

	private int flightnumber; 
	private int luggagenumber; 
	private String seat;
	public int getFlightnumber() {
		return flightnumber;
	}
	public void setFlightnumber(int flightnumber) {
		this.flightnumber = flightnumber;
	}
	public int getLuggagenumber() {
		return luggagenumber;
	}
	public void setLuggagenumber(int luggagenumber) {
		this.luggagenumber = luggagenumber;
	}
	public String getSeat() {
		return seat;
	}
	public void setSeat(String seat) {
		this.seat = seat;
	} 
	
	public static void main (String[] args) {
		
		Set<Integer> tix = new HashSet<>();
		
		tix.add(123332);
		tix.add(123213);
		tix.add(70232);

	}

}
