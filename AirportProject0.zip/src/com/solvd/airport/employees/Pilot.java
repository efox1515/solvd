package com.solvd.airport.employees;
import java.util.logging.Logger;

public class Pilot{
	
public final static Logger logger = Logger.getLogger(Pilot.class.getName());
    
    private String name;

	private static int dOB;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public static int getdOB() {
		return dOB;
	}
	public void setdOB(int dOB) {
		this.dOB = dOB;
	}

}


