package com.solvd.airport.employees;
import java.util.LinkedList;

public class PlaneStaff {
	
	private static int planeStaffNumber;
	
	public static int getPlaneStaffNumber() {
		return planeStaffNumber;
	}

	public void setPlaneStaffNumber(int planeStaffNumber) {
		this.planeStaffNumber = planeStaffNumber;
	}


	public static void main(String[]args) {
		
		
		LinkedList<String> staff = new LinkedList<>();
		
		staff.add("Dave");
		staff.add("John");
		staff.add("Carl");
		
		staff.offer("Terry");


	}



}
