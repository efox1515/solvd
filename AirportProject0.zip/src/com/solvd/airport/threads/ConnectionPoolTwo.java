package com.solvd.airport.threads;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.LinkedBlockingQueue;


public class ConnectionPoolTwo {


	private final LinkedBlockingQueue<Connection> availableConnections;

	public ConnectionPoolTwo(int poolSize) {
		availableConnections = new LinkedBlockingQueue<Connection>(poolSize);
		for (int i = 0; i < poolSize; i++) {
			availableConnections.add(new Connection());
		}
	}

	public synchronized CompletableFuture<Connection> getConnection() {
		return CompletableFuture.supplyAsync(() -> {
			try {
				return availableConnections.take();
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				System.out.println("Exception occured"+e);
				throw new RuntimeException(e);
			}
		});
	}

	public CompletionStage<Void> close() {
		return CompletableFuture.runAsync(() -> {
			for (Connection connection : availableConnections) {
				connection.close();
			}
		});
	}
}