package com.solvd.airport.threads;

import java.util.concurrent.LinkedBlockingQueue;


public class ConnectionPool {
	 private final LinkedBlockingQueue<Connection> availableConnections;

	    public ConnectionPool(int poolSize) {
	        availableConnections = new LinkedBlockingQueue<Connection>(poolSize);
	        for (int i = 0; i < poolSize; i++) {
	            availableConnections.add(new Connection());
	        }
	    }

	    public synchronized Connection getConnection() throws InterruptedException{
	        Connection connection = availableConnections.take();
	        return connection;
	    }

	    public void close() {
	        for (Connection connection : availableConnections) {
	            connection.close();
	        }
	    }
	}


