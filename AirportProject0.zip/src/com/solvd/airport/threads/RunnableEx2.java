package com.solvd.airport.threads;


public class RunnableEx2 implements Runnable{

	public void run() {
		System.out.println("Running Ex2");
	}
}