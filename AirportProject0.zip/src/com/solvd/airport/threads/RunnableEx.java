package com.solvd.airport.threads;



public class RunnableEx implements Runnable{

	@Override
	public void run() {
		System.out.println("Running");
	}
}
