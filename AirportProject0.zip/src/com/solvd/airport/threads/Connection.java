package com.solvd.airport.threads;

public class Connection {
		public void close() {
			
		}

		public void executeQuery() {
			
		}

	}


