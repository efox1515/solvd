package com.solvd.airport.threads;


public class ThreadUsage {
	
	public static void main(String[] args) {
		RunnableEx runnableEx = new RunnableEx();
		Thread thread1 = new Thread(runnableEx);
		thread1.start();

		RunnableEx2 runnableB = new RunnableEx2();
		Thread thread2 = new Thread(runnableB);
		thread2.start();

		ConnectionPool poolA = new ConnectionPool(5);

		for (int i = 0; i < 7; i++) {
			try {
				Connection connection = poolA.getConnection();
				try {
					connection.executeQuery();
				}finally {
					
				}
			} catch (InterruptedException e) {
				System.out.println("Interrupted exception");
			}
		}

		

	}

}
