package com.solvd.airport.reflection;

import java.lang.module.ModuleDescriptor.Modifier;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import com.solvd.airport.Airport;

public class Reflection {
	public static void main (String[] args)
	{
    Class cls = Airport.class;
	
	Field[] fields = cls.getDeclaredFields();
	for (Field field : fields) {
		 System.out.println("Name: " + field.getName());
		 System.out.println("Type: " + field.getType().getName());
		}
	Constructor<?>[] constructors = cls.getDeclaredConstructors();
	for (Constructor constructor : constructors)
	{
		 System.out.println("Name: " + constructors);
	}

	Method[] methods = cls.getClass().getDeclaredMethods();
	for(Method method : methods){
		System.out.println("Return Type: " + method.getReturnType());
		}
	}
}
