package com.solvd.airport;

public class Terminal {
	
	private int gate;

	public int getGate() {
		return gate;
	}

	public void setGate(int gate) {
		this.gate = gate;
	} 

}
