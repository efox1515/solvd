package com.solvd.taxiSerivce.serviceLayer;

import java.util.List;

import com.solvd.taxiSerivce.Destination;
import com.solvd.taxiService.dao.IDestinationDao;

public class DestinationService {

    private IDestinationDao destinationDao;

    public DestinationService(IDestinationDao destinationDao){
        this.destinationDao = destinationDao;
    }

    public List<Destination> getAllDestinations() throws Exception{
        return destinationDao.getAllDestinations();
    }

}