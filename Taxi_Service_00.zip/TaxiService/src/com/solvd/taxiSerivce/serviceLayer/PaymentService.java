package com.solvd.taxiSerivce.serviceLayer;

import java.util.List;

import com.solvd.taxiSerivce.Payment;
import com.solvd.taxiService.dao.IPaymentDao;
import com.solvd.taxiService.daoclasses.PaymentDao;

public class PaymentService {
	 private IPaymentDao paymentDao;

	    public PaymentService(IPaymentDao paymentDao){
	        this.paymentDao = paymentDao;
	    }

	    public List<Payment> getAllPayments() throws Exception{
	        return paymentDao.getAllPayments();
	    }

	}