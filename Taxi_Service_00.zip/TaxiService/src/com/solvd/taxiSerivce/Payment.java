package com.solvd.taxiSerivce;

import java.sql.Date;
import java.util.List;
import java.util.Map;

public class Payment {
	// Jackson Annotation
	@JsonProperty("creditCardNumber")
	private long creditCardNumber;

	@JsonProperty("expirationDate")
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "MM/dd/yyyy")
	private Date expirationDate;

	@JsonProperty("securityCode")
	private long securityCode;


    public Payment(long creditCardNumber, Date expirationDate, long securityCode) {
        this.creditCardNumber = creditCardNumber;
        this.expirationDate = expirationDate;
        this.securityCode = securityCode;
    }
    public Payment(){}
	public long getCreditCardNumber() {
		return creditCardNumber;
	}
	public void setCreditCardNumber(long creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	public Date getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}
	public long getSecurityCode() {
		return securityCode;
	}
	public void setSecurityCode(long securityCode) {
		this.securityCode = securityCode;
	}
    

}
