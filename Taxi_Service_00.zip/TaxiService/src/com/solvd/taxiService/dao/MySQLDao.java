package com.solvd.taxiService.dao;

public abstract class MySQLDao<T> implements IBaseDao<T> {
}
