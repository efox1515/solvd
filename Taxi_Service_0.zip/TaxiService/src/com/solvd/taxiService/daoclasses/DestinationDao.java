package com.solvd.taxiService.daoclasses;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.solvd.taxiSerivce.Destination;
import com.solvd.taxiSerivce.Payment;
import com.solvd.taxiService.dao.IDestinationDao;
import com.solvd.taxiService.dao.IPaymentDao;
import com.solvd.taxiService.dao.MySQLDao;

public class DestinationDao extends MySQLDao implements IDestinationDao {
	 private com.solvd.taxiSerivce.connections.ConnectionPool pool;
	    @Override
	    public Object getEntityById(long id) throws SQLException, InterruptedException {
	        String sql = "SELECT * FROM Destination WHERE locationName = ?";
	        Connection connection = (Connection) pool.getConnection();
	        PreparedStatement statement = connection.prepareStatement(sql);
	        statement.setLong(1, id);
	        ResultSet result = statement.executeQuery();
	        Destination destination = new Destination();
	        if(result.next()){
	            destination.setLocationName(result.getLong("Address"));
	        }
	        pool.getInstance().releaseConnection(connection);
	        return destination;
	    }
	    @Override
	    public List<Destination> getAllDestinations() throws InterruptedException, SQLException {
	        String sql = "SELECT * FROM Destinations";
	        Connection connection = (Connection) pool.getConnection();
	        PreparedStatement statement = connection.prepareStatement(sql);
	        ResultSet result = statement.executeQuery();
	        List<Destination> destinations = new ArrayList<>();
	        while(result.next()){
	            Destination destination = new Destination();
	            destination.setLocationName(result.getLong("Address"));
	            destinations.add(destination);
	        }
	        pool.getInstance().releaseConnection(connection);
	        return destinations;
	    }
	}