package com.solvd.taxiSerivce;

public @interface XmlRootElement {

}
