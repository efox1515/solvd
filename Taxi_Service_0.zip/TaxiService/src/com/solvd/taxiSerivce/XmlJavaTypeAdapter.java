package com.solvd.taxiSerivce;

public @interface XmlJavaTypeAdapter {

}
