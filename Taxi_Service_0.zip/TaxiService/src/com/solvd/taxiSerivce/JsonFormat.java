package com.solvd.taxiSerivce;

public @interface JsonFormat {

	String Shape = "";

	String pattern();

	String shape();

}
