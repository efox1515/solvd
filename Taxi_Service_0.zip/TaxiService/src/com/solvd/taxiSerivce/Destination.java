package com.solvd.taxiSerivce;

public class Destination {
	@JsonProperty("locationName")
	private long locationName;

    public Destination(long locationName) {
        this.locationName = locationName;

    }
    public Destination(){}
	public long getLocationName() {
		return locationName;
	}
	public void setLocationName(long locationName) {
		this.locationName = locationName;
	}

}
