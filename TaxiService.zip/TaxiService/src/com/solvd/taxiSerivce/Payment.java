package com.solvd.taxiSerivce;

import java.sql.Date;
import java.util.List;
import java.util.Map;

public class Payment {
    private long creditCardNumber, expirationDate, securityCode;

    public Payment(long creditCardNumber, long expirationDate, long securityCode) {
        this.creditCardNumber = creditCardNumber;
        this.expirationDate = expirationDate;
        this.securityCode = securityCode;
    }
    public Payment(){}
	public long getCreditCardNumber() {
		return creditCardNumber;
	}
	public void setCreditCardNumber(long creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}
	public long getExpirationDate() {
		return expirationDate;
	}
	public void setExpirationDate(long expirationDate) {
		this.expirationDate = expirationDate;
	}
	public long getSecurityCode() {
		return securityCode;
	}
	public void setSecurityCode(long securityCode) {
		this.securityCode = securityCode;
	}
    
	// Jackson Annotation
	@JsonProperty("date")
	private Date date;

	@JsonProperty("list")
	private List<Object> list;

	@JsonProperty("complexObjects")
	private Map<String, Object> complexObjects;

}
