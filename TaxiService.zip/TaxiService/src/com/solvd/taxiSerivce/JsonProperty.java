package com.solvd.taxiSerivce;

public @interface JsonProperty {

	String value();
	

}
