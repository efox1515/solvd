package com.solvd.taxiService.DaoClasses;
import com.solvd.taxiService.Dao.IBaseDao;
import com.solvd.taxiService.Dao.MySQLDao;
import com.solvd.taxiService.Dao.IPaymentDao;
import com.solvd.taxiSerivce.Payment;




import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class PaymentDao extends MySQLDao implements IPaymentDao {
    private com.solvd.taxiSerivce.Connections.ConnectionPool pool;
    @Override
    public Object getEntityById(long id) throws SQLException, InterruptedException {
        String sql = "SELECT * FROM Payments WHERE creditCard = ?";
        Connection connection = (Connection) pool.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setLong(1, id);
        ResultSet result = statement.executeQuery();
        Payment payment = new Payment();
        if(result.next()){
            payment.setCreditCard(result.getLong("creditCard"));
        }
        pool.getInstance().releaseConnection(connection);
        return payment;
    }
    @Override
    public List<Payment> getAllPayments() throws InterruptedException, SQLException {
        String sql = "SELECT * FROM Payments";
        Connection connection = (Connection) pool.getConnection();
        PreparedStatement statement = connection.prepareStatement(sql);
        ResultSet result = statement.executeQuery();
        List<Payment> payments = new ArrayList<>();
        while(result.next()){
            Payment payment = new Payment();
            payment.setCreditCard(result.getLong("creditCard"));
            payments.add(payment);
        }
        pool.getInstance().releaseConnection(connection);
        return payments;
    }
}