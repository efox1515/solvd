package com.solvd.taxiService.Dao;

import java.sql.SQLException;

public interface IBaseDao<T> {
    T getEntityById(long id) throws SQLException, InterruptedException;
}
