package com.solvd.taxiService.Dao;

public abstract class MySQLDao<T> implements IBaseDao<T> {
}
