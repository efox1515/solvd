package com.solvd.taxiService.dao;

import java.sql.SQLException;

public interface IBaseDao<T> {
    T getEntityById(long id) throws SQLException, InterruptedException;
}
